/**
 * APPU AI Chat Engine & Persona System
 * Inspired by the warmth, encouragement, and educational passion of late Dr. Puneeth Rajkumar.
 * Handles onboarding guardrails, adaptive prompt mutation, intent parsing, and n8n WhatsApp integrations.
 */

class APPUChatEngine {
  constructor() {
    this.session = {
      name: localStorage.getItem('appu_user_name') || '',
      role: localStorage.getItem('appu_user_role') || 'Student', // 'Student' or 'Parent'
      phone: localStorage.getItem('appu_user_phone') || '',
      grade: localStorage.getItem('appu_user_grade') || 'Class 10',
      isOnboarded: false
    };

    this.session.isOnboarded = !!(this.session.name && this.session.phone);
    this.onboardingStep = 0;
    this.pendingQuery = null;

    this.isOpen = false;
    this.unreadCount = 1;

    this.initDOM();
    this.updateRoleUI();
  }

  initDOM() {
    this.elements = {
      container: document.getElementById('appuWidgetContainer'),
      floatBubble: document.getElementById('appuFloatBubble'),
      chatWindow: document.getElementById('appuChatWindow'),
      chatBody: document.getElementById('chatBody'),
      chatInput: document.getElementById('chatInput'),
      sendBtn: document.getElementById('sendChatBtn'),
      closeBtn: document.getElementById('closeChatBtn'),
      roleToggleBtn: document.getElementById('roleToggleBtn'),
      roleBadge: document.getElementById('roleBadgeIndicator'),
      unreadBadge: document.getElementById('unreadBadge'),
      suggestedChips: document.getElementById('suggestedChips')
    };

    if (!this.elements.floatBubble) return;

    this.elements.floatBubble.addEventListener('click', () => this.toggleChat());
    this.elements.closeBtn.addEventListener('click', () => this.toggleChat(false));
    this.elements.sendBtn.addEventListener('click', () => this.handleUserSubmit());
    
    this.elements.chatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.handleUserSubmit();
    });

    this.elements.roleToggleBtn.addEventListener('click', () => this.switchRole());

    // Initial APPU Greeting
    setTimeout(() => {
      if (this.elements.chatBody.children.length <= 1) {
        this.renderInitialGreeting();
      }
    }, 400);
  }

  toggleChat(forceState) {
    this.isOpen = typeof forceState === 'boolean' ? forceState : !this.isOpen;
    if (this.isOpen) {
      this.elements.chatWindow.classList.add('open');
      this.elements.unreadBadge.style.display = 'none';
      this.unreadCount = 0;
      this.elements.chatInput.focus();
    } else {
      this.elements.chatWindow.classList.remove('open');
    }
  }

  switchRole() {
    this.session.role = this.session.role === 'Student' ? 'Parent' : 'Student';
    localStorage.setItem('appu_user_role', this.session.role);
    this.updateRoleUI();

    const roleMsg = this.session.role === 'Student' 
      ? "🌟 Switched to **Student Persona Mode**! I'm ready with fun stories, quick interactive quests, and step-by-step CBSE mastery! What shall we learn today?"
      : "📊 Switched to **Parent Growth Mode**! I can share structural insights, screen-time reduction strategies, and 40-hour foundation metrics for your child. How can I assist you?";

    this.addAPPUMessage(roleMsg);
  }

  updateRoleUI() {
    const isStudent = this.session.role === 'Student';
    this.elements.roleBadge.textContent = isStudent ? '🎓 Student Mode' : '📊 Parent Mode';
    this.elements.roleBadge.className = isStudent ? 'role-tag-indicator' : 'role-tag-indicator parent-mode';

    // Render suggested chips dynamically based on role
    const chips = isStudent ? [
      "📚 Send Class 10 Science syllabus to WhatsApp",
      "⚡ How do I master Math in 40 hours?",
      "🎮 Show me Gamified Quests"
    ] : [
      "📈 How does APPU boost marks by 30-50%?",
      "📱 How do we reduce screen time?",
      "📚 Send Class 10 Science syllabus to WhatsApp"
    ];

    this.elements.suggestedChips.innerHTML = chips.map(chip => `
      <button class="chip-btn" onclick="window.appuEngine.handleChipClick('${chip.replace(/'/g, "\\'")}')">${chip}</button>
    `).join('');
  }

  renderInitialGreeting() {
    let text = "";
    if (this.session.isOnboarded) {
      text = `Namaste ${this.session.name}! 🙏 Appu is so happy to see you back! As a ${this.session.role}, what high school goal or CBSE topic are we conquering today? Remember, every effort you make brings you closer to your dreams! ✨`;
    } else {
      text = `Namaste! 🙏 I'm **APPU**—your personal AI learning companion inspired by love, warmth, and passion for education! Before we start exploring CBSE concepts or syllabus guides, may I know your good name and whether you're a Student or a Parent? 🌟`;
    }

    this.addAPPUMessage(text);
  }

  handleChipClick(text) {
    this.elements.chatInput.value = text.replace(/^[^\w]+/, '').trim();
    this.handleUserSubmit();
  }

  handleUserSubmit() {
    const text = this.elements.chatInput.value.trim();
    if (!text) return;

    this.addUserMessage(text);
    this.elements.chatInput.value = '';

    // Check Onboarding Guardrail
    if (!this.session.isOnboarded) {
      this.pendingQuery = text;
      this.triggerOnboardingFlow(text);
      return;
    }

    // Process Message
    this.processQuery(text);
  }

  triggerOnboardingFlow(userMessage) {
    if (this.onboardingStep === 0) {
      this.addAPPUMessage(`I'd love to help you with that! 😊 To personalize your learning insights and deliver study materials straight to your WhatsApp, let's complete a 5-second check-in!`);
      
      this.renderOnboardingCard();
      this.onboardingStep = 1;
    }
  }

  renderOnboardingCard() {
    const cardHtml = `
      <div class="onboarding-card" id="onboardingCard">
        <div style="font-weight: 800; font-size: 0.95rem; margin-bottom: 0.75rem; color: var(--accent-gold);">
          📋 Quick 5-Second Onboarding
        </div>
        <label>Your Name</label>
        <input type="text" id="obName" placeholder="e.g., Ananya Sharma" value="${this.session.name}">

        <label>I am a:</label>
        <select id="obRole">
          <option value="Student" ${this.session.role === 'Student' ? 'selected' : ''}>Student (Grade 6-12)</option>
          <option value="Parent" ${this.session.role === 'Parent' ? 'selected' : ''}>Parent</option>
        </select>

        <label>WhatsApp Number (for syllabus & insights)</label>
        <input type="tel" id="obPhone" placeholder="e.g., 9876543210" value="${this.session.phone}">

        <button class="btn btn-gold" style="width: 100%; padding: 0.6rem; margin-top: 0.5rem; font-size: 0.88rem;" onclick="window.appuEngine.completeOnboarding()">
          🚀 Save & Continue
        </button>
      </div>
    `;

    const div = document.createElement('div');
    div.className = 'chat-bubble-row appu';
    div.innerHTML = `
      <div class="chat-bubble-content" style="width: 100%;">
        ${cardHtml}
      </div>
    `;
    this.elements.chatBody.appendChild(div);
    this.scrollToBottom();
  }

  async completeOnboarding() {
    const nameInput = document.getElementById('obName');
    const roleInput = document.getElementById('obRole');
    const phoneInput = document.getElementById('obPhone');

    if (!nameInput || !phoneInput) return;

    const name = nameInput.value.trim();
    const role = roleInput.value;
    const phone = phoneInput.value.trim();

    if (!name || !phone) {
      alert("Please provide your name and WhatsApp number to continue!");
      return;
    }

    this.session.name = name;
    this.session.role = role;
    this.session.phone = phone;
    this.session.isOnboarded = true;

    localStorage.setItem('appu_user_name', name);
    localStorage.setItem('appu_user_role', role);
    localStorage.setItem('appu_user_phone', phone);

    this.updateRoleUI();

    // Trigger n8n Data Ingestion Workflow
    const leadPayload = {
      user_name: name,
      user_role: role,
      user_phone: phone,
      grade: this.session.grade,
      source: 'APPU_Chat_Widget_LandingPage',
      timestamp: new Date().toISOString()
    };

    const n8nResult = await window.n8nClient.submitLeadCapture(leadPayload);

    // Remove onboarding card UI
    const cardEl = document.getElementById('onboardingCard');
    if (cardEl) cardEl.parentElement.innerHTML = `✅ *Thank you ${name}! Your profile is saved and registered with Appu.*`;

    this.addAPPUMessage(`Wonderful, ${name}! 🎉 You're all set! Now let me answer your query with full personalized insights.`);

    if (this.pendingQuery) {
      const q = this.pendingQuery;
      this.pendingQuery = null;
      setTimeout(() => this.processQuery(q), 500);
    }
  }

  async processQuery(text) {
    const qLower = text.toLowerCase();

    // 1. Explicit WhatsApp Syllabus Request Intent
    if (qLower.includes('send syllabus') || qLower.includes('whatsapp syllabus') || (qLower.includes('syllabus') && qLower.includes('whatsapp'))) {
      await this.handleWhatsAppSyllabusIntent(text);
      return;
    }

    // 2. Explicit Schedule Reminders Intent
    if (qLower.includes('schedule reminder') || qLower.includes('set reminder') || qLower.includes('remind me') || (qLower.includes('schedule') && qLower.includes('reminder'))) {
      await this.handleStudyScheduleIntent(text);
      return;
    }

    // 3. 15-Min Gamified Quest Intent
    if (qLower.includes('quest') || qLower.includes('gamified') || qLower.includes('challenge')) {
      await this.handleGamifiedQuestIntent(text);
      return;
    }

    // 4. Automated Diagnostic Weak-Spot Radar Intent
    if (qLower.includes('weak spot') || qLower.includes('radar') || qLower.includes('remediation') || qLower.includes('concept gap')) {
      this.triggerWeakSpotRadar();
      return;
    }

    // 5. Sunday Parent Weekly Progress Digest Intent
    if (qLower.includes('digest') || qLower.includes('weekly report') || qLower.includes('parent report') || qLower.includes('trajectory')) {
      this.triggerParentWeeklyDigest();
      return;
    }

    // 6. Adaptive n8n AI Agent Response (General queries)
    await this.handleAdaptiveAIResponse(text);
  }

  async handleGamifiedQuestIntent(userQuery) {
    this.showTypingIndicator();

    setTimeout(() => {
      this.removeTypingIndicator();

      const questTitle = "CBSE Class 10 Physics: Light & Reflection";
      const questMsg = `🎮 **DAILY 15-MIN APPU QUEST ACTIVATED!**\n` +
        `Subject: **${questTitle}**\n\n` +
        `1️⃣ **Question 1 (Concept Check)**: If the angle of incidence on a plane mirror is 35°, what is the angle of reflection?\n` +
        `  *A) 35°*  |  *B) 55°*  |  *C) 70°*\n\n` +
        `2️⃣ **Question 2 (Real-World Application)**: Why are rear-view mirrors in cars convex rather than concave?\n\n` +
        `3️⃣ **Quick Win**: Type your answer in the chat below to earn **+150 XP** and advance your 40-hour mastery streak! ⚡✨`;

      this.addAPPUMessage(questMsg);

      // Render Interactive Quest Card
      const questCardHtml = `
        <div class="whatsapp-dispatch-card" style="background: rgba(45, 212, 191, 0.15); border-color: rgba(45, 212, 191, 0.35);">
          <div class="whatsapp-dispatch-header" style="color: #0d9488;">
            <span>⚡ Daily Quest Active: +150 XP Reward</span>
          </div>
          <div style="font-size: 0.85rem; color: var(--text-sub);">
            <strong>Topic:</strong> ${questTitle}<br>
            <strong>Duration:</strong> 15 Minutes<br>
            <strong>XP Reward:</strong> 150 Points + 1 Day Streak
          </div>
          <button class="btn btn-primary" style="padding: 0.4rem 0.8rem; font-size: 0.8rem; margin-top: 0.4rem;" onclick="window.appuEngine.handleChipClick('A) 35°')">
            🎯 Submit Answer "A) 35°"
          </button>
        </div>
      `;

      const div = document.createElement('div');
      div.className = 'chat-bubble-row appu';
      div.innerHTML = `<div class="chat-bubble-content">${questCardHtml}</div>`;
      this.elements.chatBody.appendChild(div);
      this.scrollToBottom();
    }, 600);
  }

  triggerWeakSpotRadar(topic = "Convex Mirror Ray Diagrams & Focal Length") {
    this.showTypingIndicator();

    setTimeout(() => {
      this.removeTypingIndicator();

      const responseMsg = `📡 **APPU DIAGNOSTIC WEAK-SPOT RADAR ACTIVATED!**\n` +
        `Detected Concept Gap: **${topic}** (Current Accuracy: 67% ➔ Target: 90%+)\n\n` +
        `🧠 **1-MINUTE VISUAL SHORTCUT FORMULA**:\n` +
        `• Convex Mirrors ALWAYS form *Virtual, Erect, and Diminished* images, regardless of object distance!\n` +
        `• Mirror Formula Shortcut: \`1/f = 1/v + 1/u\` (For convex, focal length \`f\` is ALWAYS positive \`+f\`)\n\n` +
        `💡 **REAL-WORLD ANALOGY**:\n` +
        `Think of a convex mirror like a **wide-angle GoPro camera**—it squeezes a huge background highway into a tiny mirror so drivers see all traffic blindspots!\n\n` +
        `🎯 **MICRO-PRACTICE QUEST (Gap Elimination)**:\n` +
        `1. An object is placed 20 cm in front of a convex mirror of radius 30 cm. What is the image distance \`v\`?\n` +
        `2. Does a convex mirror ever produce a real inverted image? (Yes / No)\n\n` +
        `✨ *This Micro-Remediation Card has been dispatched to your WhatsApp!*`;

      this.addAPPUMessage(responseMsg);

      // Render WhatsApp Dispatch Card for Weak-Spot Radar
      const radarCardHtml = `
        <div class="whatsapp-dispatch-card" style="background: rgba(168, 85, 247, 0.15); border-color: rgba(168, 85, 247, 0.35);">
          <div class="whatsapp-dispatch-header" style="color: #9333ea;">
            <span>📡 1-Min Weak-Spot Micro-Remediation Dispatched!</span>
          </div>
          <div style="font-size: 0.85rem; color: var(--text-sub);">
            <strong>Targeted Weak Spot:</strong> ${topic}<br>
            <strong>Trajectory Impact:</strong> 67% ➔ 90%+ (+23% Jump)<br>
            <strong>WhatsApp Delivery:</strong> Dispatched to +91 ${this.session.phone}
          </div>
          <a href="https://wa.me/91${this.session.phone}?text=Hi%20APPU!%20I%20received%20my%201-Minute%20Weak-Spot%20Micro-Remediation%20Card." target="_blank" class="btn btn-whatsapp" style="padding: 0.4rem 0.8rem; font-size: 0.8rem; margin-top: 0.4rem;">
            📲 View Micro-Remediation on WhatsApp
          </a>
        </div>
      `;

      const div = document.createElement('div');
      div.className = 'chat-bubble-row appu';
      div.innerHTML = `<div class="chat-bubble-content">${radarCardHtml}</div>`;
      this.elements.chatBody.appendChild(div);
      this.scrollToBottom();
    }, 600);
  }

  triggerParentWeeklyDigest() {
    this.showTypingIndicator();

    setTimeout(() => {
      this.removeTypingIndicator();

      const studentName = this.session.name || "Ananya Sharma";
      const digestMsg = `📊 **APPU SUNDAY WEEKLY PROGRESS DIGEST** for **${studentName}**:\n\n` +
        `📈 **Trajectory Score**: 67% ➔ **88%** (+21% Academic Jump in 2 Weeks!)\n` +
        `🧠 **Concept Gaps Eliminated**: 14 Weak Spots Fixed in Math & Physics\n` +
        `⏱️ **Unproductive Screen Time Saved**: 60% Reduction (4.5 Hours Saved)\n` +
        `✨ **APPU Recommendation**: 15 mins on Physics Light formulas next week!\n\n` +
        `📲 *This Weekly Parent Digest has been automatically dispatched to your registered WhatsApp number!*`;

      this.addAPPUMessage(digestMsg);

      // Render Parent Digest WhatsApp Status Card
      const digestCardHtml = `
        <div class="whatsapp-dispatch-card" style="background: rgba(34, 197, 94, 0.15); border-color: rgba(34, 197, 94, 0.35);">
          <div class="whatsapp-dispatch-header" style="color: #16a34a;">
            <span>📊 Sunday Parent Digest Dispatched to WhatsApp!</span>
          </div>
          <div style="font-size: 0.85rem; color: var(--text-sub);">
            <strong>Student:</strong> ${studentName}<br>
            <strong>Current Trajectory:</strong> 67% ➔ 88% (+21% Jump)<br>
            <strong>Recipient:</strong> Parent WhatsApp (+91 ${this.session.phone})
          </div>
          <a href="https://wa.me/91${this.session.phone}?text=Hi%20APPU!%20I%20received%20the%20Sunday%20Weekly%20Progress%20Digest." target="_blank" class="btn btn-whatsapp" style="padding: 0.4rem 0.8rem; font-size: 0.8rem; margin-top: 0.4rem;">
            💬 View Weekly Digest on WhatsApp
          </a>
        </div>
      `;

      const div = document.createElement('div');
      div.className = 'chat-bubble-row appu';
      div.innerHTML = `<div class="chat-bubble-content">${digestCardHtml}</div>`;
      this.elements.chatBody.appendChild(div);
      this.scrollToBottom();
    }, 600);
  }

  async handleStudyScheduleIntent(userQuery) {
    this.showTypingIndicator();

    setTimeout(() => {
      this.removeTypingIndicator();

      const detailsAgenda = `🎯 STUDY GOAL & AGENDA:\n` +
        `• 40-Hour CBSE High School Foundation & Mastery Plan\n` +
        `• Pacing: 2 Hours Daily for 20 Days (Morning 9 AM & Evening 5 PM)\n` +
        `• Night Break: Enforced OFF after 8:30 PM\n` +
        `• Syllabus Breakdown: Math (16 hrs), Science (14 hrs), SST (6 hrs), AI Skills (4 hrs)\n` +
        `✨ Mentor Notes: Powered by IGr APPU AI. Stay focused!`;

      // 20-Day Recurring Google Calendar Template URL
      const gCalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE` +
        `&text=${encodeURIComponent('CBSE 40-Hour Study Session: APPU')}` +
        `&details=${encodeURIComponent(detailsAgenda)}` +
        `&location=${encodeURIComponent('APPU Learning Platform')}` +
        `&recur=${encodeURIComponent('RRULE:FREQ=DAILY;COUNT=20')}`;

      const responseMsg = `Awesome goal, **${this.session.name}**! 📅✨ APPU has generated your **40-Hour CBSE Mastery Schedule** starting tomorrow!\n\n` +
        `🗓️ **Schedule Plan**: 2 Hours Daily for 20 Consecutive Days (40 Hours Total)\n` +
        `🌅 **Morning Session**: 9:00 AM – 10:00 AM (1 Hour)\n` +
        `🌆 **Evening Session**: 5:00 PM – 6:00 PM (1 Hour)\n` +
        `🌙 **Night Rest**: OFF after 8:30 PM (Enforced night break!)\n\n` +
        `Click the button below to **add all 20 daily study reminders at once to your Google Calendar**!`;

      this.addAPPUMessage(responseMsg);

      // Render Schedule Confirmation Card inside chat
      const scheduleCardHtml = `
        <div class="whatsapp-dispatch-card" style="background: rgba(245, 158, 11, 0.15); border-color: rgba(245, 158, 11, 0.35);">
          <div class="whatsapp-dispatch-header" style="color: #d97706;">
            <span>📅 20-Day Recurring Calendar Reminders Ready!</span>
          </div>
          <div style="font-size: 0.85rem; color: var(--text-sub);">
            <strong>Student:</strong> ${this.session.name}<br>
            <strong>Duration:</strong> 20 Days (40 Hours Total)<br>
            <strong>Times:</strong> 9:00 AM & 5:00 PM Daily<br>
            <strong>Night Break:</strong> 8:30 PM - 8:00 AM (OFF)
          </div>
          <a href="${gCalUrl}" target="_blank" class="btn btn-gold" style="padding: 0.5rem 0.9rem; font-size: 0.82rem; margin-top: 0.4rem; display: inline-flex; align-items: center; gap: 0.4rem;">
            📅 Add All 20 Daily Reminders to Google Calendar
          </a>
        </div>
      `;

      const div = document.createElement('div');
      div.className = 'chat-bubble-row appu';
      div.innerHTML = `<div class="chat-bubble-content">${scheduleCardHtml}</div>`;
      this.elements.chatBody.appendChild(div);
      this.scrollToBottom();
    }, 600);
  }

  async handleWhatsAppSyllabusIntent(userQuery) {
    this.showTypingIndicator();

    // Parse grade and subject
    let grade = "Class 10th";
    if (userQuery.match(/class\s*([0-9]{1,2})/i)) {
      grade = "Class " + userQuery.match(/class\s*([0-9]{1,2})/i)[1] + "th";
    }

    let subject = "Science & Mathematics";
    if (userQuery.toLowerCase().includes('science')) subject = "Science";
    else if (userQuery.toLowerCase().includes('math')) subject = "Mathematics";
    else if (userQuery.toLowerCase().includes('social')) subject = "Social Science";

    const requestedSyllabus = `${grade} ${subject} Complete CBSE 2026-27 Syllabus Guide`;

    const payload = {
      user_name: this.session.name,
      user_phone: this.session.phone,
      user_role: this.session.role,
      requested_syllabus: requestedSyllabus,
      grade: grade,
      timestamp: new Date().toISOString()
    };

    const n8nRes = await window.n8nClient.triggerWhatsAppSyllabus(payload);

    this.removeTypingIndicator();

    const responseMsg = `Great choice, ${this.session.name}! 📚 I have parsed your request for the **${requestedSyllabus}**. My n8n automated delivery system has dispatched the file directly to your WhatsApp number (**${this.session.phone}**)!`;

    this.addAPPUMessage(responseMsg);

    // Render WhatsApp Dispatch Status Card
    const dispatchCardHtml = `
      <div class="whatsapp-dispatch-card">
        <div class="whatsapp-dispatch-header">
          <span>📲 WhatsApp Automated Dispatch Successful!</span>
        </div>
        <div style="font-size: 0.85rem; color: var(--text-sub);">
          <strong>Document:</strong> ${requestedSyllabus}<br>
          <strong>Sent to:</strong> +91 ${this.session.phone}<br>
          <strong>n8n Execution ID:</strong> <code>${n8nRes.executionId || 'exec_active_01'}</code>
        </div>
        <a href="https://wa.me/91${this.session.phone}?text=Hi%20APPU!%20I%20received%20my%20${encodeURIComponent(requestedSyllabus)}" target="_blank" class="btn btn-whatsapp" style="padding: 0.4rem 0.8rem; font-size: 0.8rem; margin-top: 0.4rem;">
          💬 Open WhatsApp Chat
        </a>
      </div>
    `;

    const div = document.createElement('div');
    div.className = 'chat-bubble-row appu';
    div.innerHTML = `<div class="chat-bubble-content">${dispatchCardHtml}</div>`;
    this.elements.chatBody.appendChild(div);
    this.scrollToBottom();
  }

  handleEfficacyQuery() {
    this.showTypingIndicator();
    setTimeout(() => {
      this.removeTypingIndicator();
      let text = "";
      if (this.session.role === 'Parent') {
        text = `As a parent, your main priority is learning quality over screen quantity. **IGr reduces unproductive screen time by up to 60%** because APPU uses micro-targeted 15-minute diagnostic quests instead of endless video scrolling. Within 40 focused hours, students achieve strong conceptual clarity, leading to an **academic boost of 30-50%**! 📈 You can track real-time mastery on your Parent Dashboard.`;
      } else {
        text = `Hey ${this.session.name}! 🚀 With APPU, you don't need to sit for hours staring at boring screens! In just **40 total hours**, APPU breaks complex topics into bite-sized gamified quests. You learn faster, retain 2x more, and still have plenty of time for sports and hobbies! 🏆`;
      }
      this.addAPPUMessage(text);
    }, 600);
  }

  async handleAdaptiveAIResponse(query) {
    this.showTypingIndicator();
    
    // Construct rich profile context string for n8n AI Agent
    const fullQuery = `[Student Profile: Name=${this.session.name}, Role=${this.session.role}, Phone=${this.session.phone}, Grade=${this.session.grade}] User Query: ${query}`;
    const sessionId = 'session_' + (this.session.phone || 'guest_' + Date.now());

    const liveResponse = await window.n8nClient.sendChatToAgent(fullQuery, sessionId);
    this.removeTypingIndicator();

    if (liveResponse && typeof liveResponse === 'string' && liveResponse.trim().length > 0) {
      this.addAPPUMessage(liveResponse);
      return;
    }

    // Fallback persona response if offline
    let text = "";
    if (this.session.role === 'Student') {
      text = `That's a fantastic question, ${this.session.name}! 🌟 Every step you take to understand this topic makes you smarter and more confident. Let's break it down together in a fun, step-by-step way!\n\n1️⃣ **Core Concept**: Think of this like building a super-strong foundation for a tall skyscraper.\n2️⃣ **Real-World Connection**: You see this happening every day around you!\n3️⃣ **Quick Win**: Practice just 3 targeted questions with APPU and you'll master this in no time!\n\nRemember: Small steps lead to giant leaps! Keep shining! Appu is always here for you! ✨`;
    } else {
      text = `Thank you for asking, ${this.session.name}. 📊 In our Parent Framework for CBSE high school preparation:\n\n1. **Diagnostic Assessment**: APPU pinpoints exact concept gaps in real-time.\n2. **Targeted Mastery**: Study time focuses 100% on weak areas.\n3. **Full Transparency**: Real-time progress updates on your dashboard.\n\nWould you like to book a 1-on-1 Discovery Call or receive our detailed CBSE curriculum roadmap on WhatsApp?`;
    }
    this.addAPPUMessage(text);
  }

  addUserMessage(text) {
    const div = document.createElement('div');
    div.className = 'chat-bubble-row user';
    div.innerHTML = `<div class="chat-bubble-content">${this.escapeHTML(text)}</div>`;
    this.elements.chatBody.appendChild(div);
    this.scrollToBottom();
  }

  addAPPUMessage(text) {
    const div = document.createElement('div');
    div.className = 'chat-bubble-row appu';
    div.innerHTML = `<div class="chat-bubble-content">${this.formatMarkdown(text)}</div>`;
    this.elements.chatBody.appendChild(div);

    const lower = text.toLowerCase();

    // Auto-detect WhatsApp syllabus request and attach interactive WhatsApp Card
    if ((lower.includes('whatsapp') || lower.includes('syllabus') || lower.includes('dispatched')) && this.session.phone) {
      const cleanMsg = text.replace(/[*_#`]/g, ''); // Strip markdown symbols for crisp WhatsApp formatting
      const cardHtml = `
        <div class="whatsapp-dispatch-card" style="margin-top: 0.5rem;">
          <div class="whatsapp-dispatch-header">
            <span>📲 Full CBSE Syllabus & Study Notes Ready</span>
          </div>
          <div style="font-size: 0.85rem; color: var(--text-sub);">
            <strong>Recipient:</strong> +91 ${this.session.phone}<br>
            <strong>Status:</strong> Full syllabus guide formatted for WhatsApp
          </div>
          <a href="https://wa.me/91${this.session.phone}?text=${encodeURIComponent('📚 IGr APPU - CBSE Study Guide & Syllabus:\n\n' + cleanMsg)}" target="_blank" class="btn btn-whatsapp" style="padding: 0.45rem 0.9rem; font-size: 0.82rem; margin-top: 0.4rem; display: inline-flex; align-items: center; gap: 0.4rem;">
            💬 Receive Full Syllabus in WhatsApp
          </a>
        </div>
      `;
      const cardDiv = document.createElement('div');
      cardDiv.className = 'chat-bubble-row appu';
      cardDiv.innerHTML = `<div class="chat-bubble-content" style="background: transparent; padding: 0;">${cardHtml}</div>`;
      this.elements.chatBody.appendChild(cardDiv);
    }

    // Auto-detect Calendar Reminder request and attach interactive Google Calendar Card
    if (lower.includes('reminder') || lower.includes('calendar') || lower.includes('scheduled')) {
      // Filter out conversational chat filler lines
      const cleanLines = text.split('\n')
        .map(line => line.replace(/[*_#`]/g, '').trim())
        .filter(line => line.length > 0 && 
          !line.toLowerCase().includes('successfully scheduled') &&
          !line.toLowerCase().includes('further assistance') &&
          !line.toLowerCase().includes('happy studying') &&
          !line.toLowerCase().includes('feel free to ask')
        );

      const cleanAgenda = cleanLines.length > 0 ? cleanLines.join('\n• ') : 'Study session for target CBSE topic';
      const eventTitle = `📚 CBSE Study Session: APPU`;
      const eventDetails = `🎯 STUDY GOAL & AGENDA:\n• ${cleanAgenda}\n\n📌 ACTION PLAN:\n• Review key concepts & core formulas\n• Solve 3 targeted APPU Quest practice problems\n\n✨ APPU Notes: Stay focused! Small steps lead to giant leaps. Powered by IGr APPU.`;

      const cardHtml = `
        <div class="whatsapp-dispatch-card" style="margin-top: 0.5rem; background: rgba(14, 165, 233, 0.15); border-color: rgba(14, 165, 233, 0.3);">
          <div class="whatsapp-dispatch-header" style="color: var(--secondary);">
            <span>📅 Structured Study Agenda Ready</span>
          </div>
          <div style="font-size: 0.85rem; color: var(--text-sub);">
            <strong>Event:</strong> ${eventTitle}<br>
            <strong>Status:</strong> Bulleted action plan ready for Google Calendar
          </div>
          <a href="https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(eventTitle)}&details=${encodeURIComponent(eventDetails)}" target="_blank" class="btn btn-secondary" style="padding: 0.45rem 0.9rem; font-size: 0.82rem; margin-top: 0.4rem; display: inline-flex; align-items: center; gap: 0.4rem; background: var(--secondary); color: #fff;">
            📅 Save Bulleted Agenda to Google Calendar
          </a>
        </div>
      `;
      const cardDiv = document.createElement('div');
      cardDiv.className = 'chat-bubble-row appu';
      cardDiv.innerHTML = `<div class="chat-bubble-content" style="background: transparent; padding: 0;">${cardHtml}</div>`;
      this.elements.chatBody.appendChild(cardDiv);
    }

    this.scrollToBottom();
  }

  showTypingIndicator() {
    const div = document.createElement('div');
    div.id = 'typingIndicator';
    div.className = 'chat-bubble-row appu';
    div.innerHTML = `
      <div class="chat-bubble-content" style="color: var(--text-muted); font-style: italic;">
        <span>Appu is thinking with warmth... 💡</span>
      </div>
    `;
    this.elements.chatBody.appendChild(div);
    this.scrollToBottom();
  }

  removeTypingIndicator() {
    const el = document.getElementById('typingIndicator');
    if (el) el.remove();
  }

  scrollToBottom() {
    this.elements.chatBody.scrollTop = this.elements.chatBody.scrollHeight;
  }

  escapeHTML(str) {
    return str.replace(/[&<>'"]/g, 
      tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
    );
  }

  formatMarkdown(str) {
    let formatted = this.escapeHTML(str);
    formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    formatted = formatted.replace(/\*(.*?)\*/g, '<em>$1</em>');
    formatted = formatted.replace(/`([^`]+)`/g, '<code>$1</code>');
    formatted = formatted.replace(/\n/g, '<br>');
    return formatted;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.appuEngine = new APPUChatEngine();
});
