/**
 * IGr Premium Animation Layer
 * Lenis smooth scroll + GSAP window.ScrollTrigger + Grain + Cursor effects
 * Reference: callbaba.com, awwwards-level choreography
 */

// GSAP and plugins loaded via global from CDN in HTML
// This file expects window.gsap, window.ScrollTrigger, and Lenis to be available globally

window.gsap.registerPlugin(window.ScrollTrigger);

class IGrAnimations {
  constructor() {
    this.lenis = null;
    this.cursor = { x: 0, y: 0, targetX: 0, targetY: 0 };
    this.grainCanvas = null;
    this.grainCtx = null;
    this.init();
  }

  init() {
    this.initLenis();
    this.initGrain();
    this.initCursorSpotlight();
    this.initNavbarMorph();
    this.initHeroPinned();
    this.initSectionReveals();
    this.initMagneticButtons();
  }

  /**
   * Lenis Smooth Scroll
   * Enterprise-level smoothness with proper RAF integration
   */
  initLenis() {
    this.lenis = new window.Lenis({
      duration: 0.9,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: false,
      syncTouch: true,
      touchMultiplier: 1.8,
      infinite: false,
    });

    this.lenis.on('scroll', window.ScrollTrigger.update);

    window.gsap.ticker.add((time) => {
      this.lenis.raf(time * 1000);
    });
    window.gsap.ticker.lagSmoothing(0);
  }

  /**
   * Film Grain Texture Overlay
   * Creates that organic, living surface texture
   */
  initGrain() {
    this.grainCanvas = document.createElement('canvas');
    this.grainCanvas.id = 'grain-overlay';
    this.grainCanvas.style.cssText = `
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 9999;
      opacity: 0.035;
      mix-blend-mode: overlay;
    `;
    document.body.appendChild(this.grainCanvas);

    this.grainCtx = this.grainCanvas.getContext('2d');
    this.resizeGrain();
    this.animateGrain();

    window.addEventListener('resize', () => this.resizeGrain(), { passive: true });
  }

  resizeGrain() {
    this.grainCanvas.width = window.innerWidth;
    this.grainCanvas.height = window.innerHeight;
  }

  animateGrain() {
    const { width, height } = this.grainCanvas;
    const imageData = this.grainCtx.createImageData(width, height);
    const data = imageData.data;

    for (let i = 0; i < data.length; i += 4) {
      const value = Math.random() * 255;
      data[i] = value;
      data[i + 1] = value;
      data[i + 2] = value;
      data[i + 3] = 255;
    }

    this.grainCtx.putImageData(imageData, 0, 0);
    requestAnimationFrame(() => this.animateGrain());
  }

  initCursorSpotlight() {
    // Native SVG cursor is handled via CSS in style.css
  }

  /**
   * Navbar Morph on Scroll
   * Glass to solid, subtle blur backdrop
   */
  initNavbarMorph() {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;

    let lastScrollY = window.scrollY;

    window.ScrollTrigger.create({
      onUpdate: (self) => {
        const currentScroll = self.scroll();
        const delta = currentScroll - lastScrollY;

        // Scroll DOWN -> shrink navbar capsule (.scrolled)
        if (delta > 5 && currentScroll > 50) {
          navbar.classList.add('scrolled');
        } 
        // Scroll UP (anywhere on page) -> expand navbar capsule (remove .scrolled)
        else if (delta < -5 || currentScroll <= 50) {
          navbar.classList.remove('scrolled');
        }

        lastScrollY = currentScroll;
      }
    });
  }

  /**
   * Hero Pinned Scroll Sequence
   * Focal moment: Headline transforms as user scrolls
   */
  initHeroPinned() {
    const hero = document.querySelector('.hero-section');
    const heroContent = hero.querySelector('.hero-content');
    if (!heroContent) return;

    const headline = hero.querySelector('h1');
    const gradientText = headline.querySelector('.gradient-text');
    const heroSub = hero.querySelector('.hero-sub');
    const checkmarks = hero.querySelector('.hero-checkmarks');
    const ctaGroup = hero.querySelector('.hero-cta-group');

    // Pin the hero during transformation
    // Use pinSpacing:false to prevent extra scroll space after pin
    const tl = window.gsap.timeline({
      scrollTrigger: {
        trigger: hero,
        start: 'top top',
        end: '+=100vh',
        pin: true,
        pinSpacing: false,
        scrub: 0.3,
        anticipatePin: 1,
      }
    });

    // PHASE 0 (0-10%): Settle — everything breathes slightly, establishing baseline

    // PHASE 1: Subtitle and checkmarks fade
    tl.to([heroSub, checkmarks], {
      y: 40,
      opacity: 0,
      duration: 0.2,
      stagger: 0.05,
      ease: 'power2.out'
    }, 0.1);

    // CTAs slide away
    tl.to(ctaGroup, {
      y: 60,
      opacity: 0,
      duration: 0.15,
      ease: 'power2.in'
    }, 0.15);

    // PHASE 2 (30-60%): "Why Is Education The Same?" — Rise
    // The gradient text becomes the focus, scales with depth
    tl.to(gradientText, {
      scale: 1.25,
      y: -30,
      textShadow: '0 0 60px rgba(139, 92, 246, 0.4)',
      duration: 0.3,
      ease: 'power3.out'
    }, 0.3);

    // PHASE 3: Hero content fades to transition
    tl.to(heroContent, {
      opacity: 0,
      scale: 0.95,
      duration: 0.2,
      ease: 'power2.in'
    }, 0.7);

    // Cleanup: Return everything to natural DOM state
    tl.set([heroContent, headline, gradientText, heroSub, checkmarks, ctaGroup], {
      clearProps: 'all',
      overwrite: true
    });
  }

  /**
   * Section Reveals
   * Unique choreography per section—no generic fades
   */
  initSectionReveals() {
    // Meet IGr section - clip-path reveal from center
    const meetSection = document.querySelector('#meet-igr');
    if (meetSection) {
      window.gsap.fromTo(meetSection,
        { clipPath: 'inset(10% 10% 10% 10% round 20px)' },
        {
          clipPath: 'inset(0% 0% 0% 0% round 0px)',
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: meetSection,
            start: 'top 80%',
            end: 'top 30%',
            scrub: 0.3,
          }
        }
      );

      // Feature cards stagger with depth
      const featureCards = meetSection.querySelectorAll('.feature-card');
      featureCards.forEach((card, i) => {
        window.gsap.fromTo(card,
          { y: 60, opacity: 0, rotateX: 15 },
          {
            y: 0,
            opacity: 1,
            rotateX: 0,
            duration: 0.6,
            delay: i * 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      });
    }

    // Stats cards - number tickers with spring physics
    const statNumbers = document.querySelectorAll('.stat-number');
    statNumbers.forEach((stat) => {
      const finalText = stat.textContent;
      const numericMatch = finalText.match(/[\d.-]+/);
      if (numericMatch) {
        const finalValue = parseFloat(numericMatch[0]);
        const prefix = finalText.substring(0, finalText.indexOf(numericMatch[0]));
        const suffix = finalText.substring(finalText.indexOf(numericMatch[0]) + numericMatch[0].toString().length);

        window.ScrollTrigger.create({
          trigger: stat,
          start: 'top 80%',
          onEnter: () => {
            window.gsap.fromTo(stat,
              { innerText: 0 },
              {
                innerText: finalValue,
                duration: 1.5,
                ease: 'power2.out',
                snap: { innerText: finalValue % 1 === 0 ? 1 : 0.1 },
                onUpdate: function() {
                  const current = parseFloat(stat.innerText) || 0;
                  stat.innerText = prefix + current.toFixed(finalValue % 1 === 0 ? 0 : 1) + suffix;
                }
              }
            );
          },
          once: true
        });
      }
    });

    // Steps container - horizontal reveal
    const stepsContainer = document.querySelector('.steps-container');
    if (stepsContainer) {
      const stepCards = stepsContainer.querySelectorAll('.step-card');
      stepCards.forEach((card, i) => {
        window.gsap.fromTo(card,
          { x: -50, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.5,
            delay: i * 0.15,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: stepsContainer,
              start: 'top 75%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      });
    }

    // FAQ accordion items - slide from left with mask
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach((item, i) => {
      window.gsap.fromTo(item,
        { x: -30, opacity: 0, clipPath: 'inset(0 100% 0 0)' },
        {
          x: 0,
          opacity: 1,
          clipPath: 'inset(0 0% 0 0)',
          duration: 0.5,
          delay: i * 0.08,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: item,
            start: 'top 85%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    });
  }

  /**
   * Magnetic Buttons
   * Spring physics on hover—pulls toward cursor
   */
  initMagneticButtons() {
    const buttons = document.querySelectorAll('.btn');

    if (!window.matchMedia('(pointer: fine)').matches) return;

    buttons.forEach((btn) => {
      btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;

        window.gsap.to(btn, {
          x: x * 0.3,
          y: y * 0.3,
          duration: 0.3,
          ease: 'power2.out'
        });
      });

      btn.addEventListener('mouseleave', () => {
        window.gsap.to(btn, {
          x: 0,
          y: 0,
          duration: 0.5,
          ease: 'elastic.out(1, 0.3)'
        });
      });

      // Press feedback
      btn.addEventListener('mousedown', () => {
        window.gsap.to(btn, {
          scale: 0.96,
          duration: 0.1,
          ease: 'power2.out'
        });
      });

      btn.addEventListener('mouseup', () => {
      btn.addEventListener('mouseup', () => {
        window.gsap.to(btn, {
          scale: 1,
          duration: 0.3,
          ease: 'elastic.out(1, 0.5)'
        });
      });
    });
  }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  new IGrAnimations();
});
